package com.library.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api")
public class AuthController {

    // Predefined admin credentials
    private static final String ADMIN_NAME = "Jim";
    private static final String ADMIN_EMAIL = "jimjeffry@gmail.com";

    // Admin login - accepts name & email (with predefined validation)
    @PostMapping("/admin/login")
    public ResponseEntity<?> adminLogin(@RequestBody Map<String, String> payload) {
        String name = payload.get("name");
        String email = payload.get("email");
        
        // Check if name and email are provided
        if (name == null || email == null) {
            return ResponseEntity.badRequest().body(Map.of("message", "Name and email are required"));
        }
        
        // Validate against predefined admin credentials
        if (ADMIN_NAME.equals(name) && ADMIN_EMAIL.equals(email)) {
            return ResponseEntity.ok(Map.of(
                "message", "Admin login successful", 
                "name", name, 
                "email", email
            ));
        } else {
            return ResponseEntity.status(401).body(Map.of(
                "message", "Invalid admin credentials"
            ));
        }
    }

    // User login - accepts name, email, phone (no DB validation)
    @PostMapping("/user/login")
    public ResponseEntity<?> userLogin(@RequestBody Map<String, String> payload) {
        String name = payload.get("name");
        String email = payload.get("email");
        String phone = payload.get("phone");
        
        if (name == null || email == null || phone == null) {
            return ResponseEntity.badRequest().body(Map.of("message", "Name, email and phone are required"));
        }
        
        return ResponseEntity.ok(Map.of(
            "message", "User login successful", 
            "name", name, 
            "email", email, 
            "phone", phone
        ));
    }
}