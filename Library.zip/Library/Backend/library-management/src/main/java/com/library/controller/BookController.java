package com.library.controller;

import com.library.entity.Book;
import com.library.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/books")
public class BookController {
    private final BookService service;

    @Autowired
    public BookController(BookService service) {
        this.service = service;
    }

    @PostMapping("/add")
    public ResponseEntity<?> addBook(@RequestBody Book book) {
        try {
            Book saved = service.addBook(book);
            return ResponseEntity.ok(saved);
        } catch (DataIntegrityViolationException ex) {
            return ResponseEntity.badRequest().body(Map.of("message", "uniqueCode must be unique"));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("message", e.getMessage()));
        }
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<?> updateBook(@PathVariable Long id, @RequestBody Book updated) {
        try {
            Book saved = service.updateBook(id, updated);
            return ResponseEntity.ok(saved);
        } catch (RuntimeException ex) {
            return ResponseEntity.badRequest().body(Map.of("message", ex.getMessage()));
        }
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<?> deleteBook(@PathVariable Long id) {
        try {
            service.deleteBook(id);
            return ResponseEntity.ok(Map.of("message", "Book deleted"));
        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(Map.of("message", ex.getMessage()));
        }
    }

    @PutMapping("/status/{id}")
    public ResponseEntity<?> toggleStatus(@PathVariable Long id, @RequestParam boolean active) {
        try {
            Book updated = service.toggleStatus(id, active);
            return ResponseEntity.ok(updated);
        } catch (RuntimeException ex) {
            return ResponseEntity.badRequest().body(Map.of("message", ex.getMessage()));
        }
    }

    @GetMapping("/page")
    public ResponseEntity<?> getPagedBooks(@RequestParam(defaultValue = "0") int page,
                                           @RequestParam(defaultValue = "10") int size) {
        Page<Book> p = service.getPagedBooks(page, size);
        // create response list mapping stock==0 -> out of stock note
        Map<String, Object> resp = new HashMap<>();
        List<Map<String, Object>> booksList = new ArrayList<>();
        for (Book b : p.getContent()) {
            Map<String, Object> m = new HashMap<>();
            m.put("id", b.getId());
            m.put("name", b.getName());
            m.put("author", b.getAuthor());
            m.put("uniqueCode", b.getUniqueCode());
            m.put("stock", b.getStock());
            m.put("active", b.isActive());
            m.put("availability", b.getStock() <= 0 ? "Out of Stock" : "Available");
            booksList.add(m);
        }
        resp.put("books", booksList);
        resp.put("page", p.getNumber());
        resp.put("size", p.getSize());
        resp.put("totalElements", p.getTotalElements());
        resp.put("totalPages", p.getTotalPages());
        return ResponseEntity.ok(resp);
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getById(@PathVariable Long id) {
        Optional<Book> b = service.getById(id);
        if (b.isPresent()) {
            Book book = b.get();
            Map<String, Object> m = new HashMap<>();
            m.put("id", book.getId());
            m.put("name", book.getName());
            m.put("author", book.getAuthor());
            m.put("uniqueCode", book.getUniqueCode());
            m.put("stock", book.getStock());
            m.put("active", book.isActive());
            m.put("availability", book.getStock() <= 0 ? "Out of Stock" : "Available");
            return ResponseEntity.ok(m);
        } else {
            return ResponseEntity.status(404).body(Map.of("message", "Book not found"));
        }
    }
}