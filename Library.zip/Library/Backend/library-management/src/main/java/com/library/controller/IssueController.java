package com.library.controller;

import com.library.entity.IssueRecord;
import com.library.entity.Book;
import com.library.service.BookService;
import com.library.service.IssueService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/api/issues")
public class IssueController {
    private final IssueService issueService;
    private final BookService bookService;

    @Autowired
    public IssueController(IssueService issueService, BookService bookService) {
        this.issueService = issueService;
        this.bookService = bookService;
    }

    @PostMapping("/issue")
    public ResponseEntity<?> issueBook(@RequestBody IssueRecord request,
                                       @RequestParam(required = false) String uniqueCode) {
        Book book = null;

        if (request.getBookId() != null) {
            // Find by ID
            book = bookService.getById(request.getBookId())
                              .orElse(null);
        } else if (uniqueCode != null) {
            // Find by uniqueCode
            book = bookService.findByUniqueCode(uniqueCode)
                              .orElse(null);
        }

        if (book == null) {
            return ResponseEntity.badRequest().body(Map.of("message", "Book not found"));
        }

        if (!book.isActive()) {
            return ResponseEntity.badRequest().body(Map.of("message", "Book is temporarily inactive"));
        }

        if (book.getStock() <= 0) {
            return ResponseEntity.badRequest().body(Map.of("message", "Out of Stock"));
        }

        // Decrement stock
        bookService.decrementStock(book.getId());

        // Save issue record
        IssueRecord saved = issueService.issueBook(request);
        return ResponseEntity.ok(saved);
    }


    @GetMapping("/all")
    public ResponseEntity<?> getAllIssues() {
        List<IssueRecord> list = issueService.getAllIssuesLatestFirst();
        return ResponseEntity.ok(list);
    }
}