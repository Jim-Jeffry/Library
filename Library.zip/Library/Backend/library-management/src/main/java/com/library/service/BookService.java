package com.library.service;

import com.library.entity.Book;
import com.library.repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class BookService {
    private final BookRepository repo;

    @Autowired
    public BookService(BookRepository repo) {
        this.repo = repo;
    }

    public Book addBook(Book book) {
        // uniqueCode should be unique - repository has unique constraint; handle exception at controller
        return repo.save(book);
    }

    public Optional<Book> getById(Long id) {
        return repo.findById(id);
    }

    public Page<Book> getPagedBooks(int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by("id").descending());
        return repo.findAll(pageable);
    }

    public Book updateBook(Long id, Book updated) {
        return repo.findById(id).map(book -> {
            book.setName(updated.getName());
            book.setAuthor(updated.getAuthor());
            book.setUniqueCode(updated.getUniqueCode());
            book.setStock(updated.getStock());
            book.setActive(updated.isActive());
            return repo.save(book);
        }).orElseThrow(() -> new RuntimeException("Book not found with id " + id));
    }

    public void deleteBook(Long id) {
        repo.deleteById(id);
    }

    public Book toggleStatus(Long id, boolean active) {
        return repo.findById(id).map(book -> {
            book.setActive(active);
            return repo.save(book);
        }).orElseThrow(() -> new RuntimeException("Book not found with id " + id));
    }

    public Optional<Book> findByUniqueCode(String uniqueCode) {
        return repo.findByUniqueCode(uniqueCode);
    }

    public Book decrementStock(Long bookId) {
        Book book = repo.findById(bookId).orElseThrow(() -> new RuntimeException("Book not found"));
        if (book.getStock() <= 0) {
            throw new RuntimeException("Out of Stock");
        }
        book.setStock(book.getStock() - 1);
        return repo.save(book);
    }

	public Optional<Book> getByUniqueCode(String uniqueCode) {
		// TODO Auto-generated method stub
		return repo.findByUniqueCode(uniqueCode);
	}
}