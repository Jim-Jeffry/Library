package com.library.service;

import com.library.entity.IssueRecord;
import com.library.repository.IssueRecordRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class IssueService {
    private final IssueRecordRepository repo;

    @Autowired
    public IssueService(IssueRecordRepository repo) {
        this.repo = repo;
    }

    public IssueRecord issueBook(IssueRecord record) {
        return repo.save(record);
    }

    public List<IssueRecord> getAllIssuesLatestFirst() {
        return repo.findAllByOrderByIssueDateDesc();
    }
}
