create database library_db;
use library_db;

